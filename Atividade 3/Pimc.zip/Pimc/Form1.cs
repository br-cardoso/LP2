﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void MsktxtPeso_Validated(object sender, EventArgs e)
        {
            double peso;
            if (!double.TryParse(msktxtPeso.Text, out peso) || (peso <= 0))
                {
                MessageBox.Show("Peso Inválido");
                errorProvider1.SetError(msktxtPeso, "Peso Inválido");
            }

        }

        private void MsktxtAltura_Validated(object sender, EventArgs e)
        {
            double altura;
            if (!double.TryParse(msktxtAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura Inválida");
                errorProvider2.SetError(msktxtAltura, "Altura Inválida");
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double imc, peso, altura;
            if (double.TryParse(msktxtAltura.Text, out altura) && 
                (double.TryParse(msktxtPeso.Text, out peso)))
                {
                if((altura <= 0) || (peso <=0))
                    MessageBox.Show("Valorem devem ser maiores que zero!");
                else
                {
                    imc = peso / Math.Pow(altura, 2);
                    imc = Math.Round(imc, 1);

                    txtIMC.Text = imc.ToString();

                    if (imc < 18.5)
                        txtIMC.Text += "  classificação: magreza";
                    else
                        if (imc < 24.9)
                        txtIMC.Text += "  classificação: normal";
                    else
                        if (imc < 29.9)
                        txtIMC.Text += "  classificação: sobrepeso";
                    else
                        if (imc < 39.9)
                        txtIMC.Text += "  classificação: obesidade";
                    else
                        txtIMC.Text += "  classificação: obesidade grave";
                }
            }

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            msktxtAltura.Text = string.Empty;
            msktxtPeso.Text = string.Empty;
            txtIMC.Text = "";
        }
    }
}
