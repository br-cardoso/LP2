﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void FrmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void BtnNum_Click(object sender, EventArgs e)
        {
            int contador = 0;
            for (var i=0; i<rctxtFrase.Text.Length; i++)
            {
                if (char.IsNumber(rctxtFrase.Text[i]))
                    contador++;
            }

            txtNm.Text = contador.ToString(); 
        }

        private void BtnLetras_Click(object sender, EventArgs e)
        {
            {
                int contador = 0;
                foreach (var c in rctxtFrase.Text)
                {
                    if (char.IsLetter(c))
                        contador++;
                }

                txtLetras.Text = contador.ToString();
            }
        }

        private void BtnBranco_Click(object sender, EventArgs e)
        {
            int pos = 0, i = 0;
            while (i < rctxtFrase.Text.Length)
            {
                if (char.IsWhiteSpace(rctxtFrase.Text[i]))
                {
                    pos = i + 1;
                }
                if (pos > 0)
                    txtBranco.Text = pos.ToString();
                else
                    txtBranco.Text = ("Não há espaço em branco");
                i++;


            }
        }
    }
}
