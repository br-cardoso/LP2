﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void BtnRemove1_Click(object sender, EventArgs e)
        {
            int posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text);

            while ( posicao >= 0)
            {
                txtPalavra2.Text = txtPalavra2.Text.Substring(0, posicao) + txtPalavra2.Text.Substring(txtPalavra1.Text.Length + posicao);

                posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = string.Empty;
            txtPalavra1.Text = string.Empty;
        }

        private void BtnRemove1Replace_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");

        }

        private void BtnInverter_Click(object sender, EventArgs e)
        {
            char[] palavra = txtPalavra1.Text.ToCharArray();
            Array.Reverse(palavra);

            //foreach (char c in palavra)
            //txtPalavra2.Text += c;

            txtPalavra2.Text = new string(palavra);
        }
    }
}
