﻿namespace pMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rctxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnNum = new System.Windows.Forms.Button();
            this.btnLetras = new System.Windows.Forms.Button();
            this.btnBranco = new System.Windows.Forms.Button();
            this.lblFrase = new System.Windows.Forms.Label();
            this.txtNm = new System.Windows.Forms.TextBox();
            this.txtLetras = new System.Windows.Forms.TextBox();
            this.txtBranco = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // rctxtFrase
            // 
            this.rctxtFrase.Location = new System.Drawing.Point(119, 135);
            this.rctxtFrase.Name = "rctxtFrase";
            this.rctxtFrase.Size = new System.Drawing.Size(487, 96);
            this.rctxtFrase.TabIndex = 0;
            this.rctxtFrase.Text = "";
            // 
            // btnNum
            // 
            this.btnNum.Location = new System.Drawing.Point(119, 278);
            this.btnNum.Name = "btnNum";
            this.btnNum.Size = new System.Drawing.Size(126, 34);
            this.btnNum.TabIndex = 1;
            this.btnNum.Text = "Contar Números";
            this.btnNum.UseVisualStyleBackColor = true;
            this.btnNum.Click += new System.EventHandler(this.BtnNum_Click);
            // 
            // btnLetras
            // 
            this.btnLetras.Location = new System.Drawing.Point(480, 278);
            this.btnLetras.Name = "btnLetras";
            this.btnLetras.Size = new System.Drawing.Size(126, 34);
            this.btnLetras.TabIndex = 2;
            this.btnLetras.Text = "Contar Letras";
            this.btnLetras.UseVisualStyleBackColor = true;
            this.btnLetras.Click += new System.EventHandler(this.BtnLetras_Click);
            // 
            // btnBranco
            // 
            this.btnBranco.Location = new System.Drawing.Point(305, 278);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(126, 34);
            this.btnBranco.TabIndex = 3;
            this.btnBranco.Text = "Primeiro char em branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.BtnBranco_Click);
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFrase.Location = new System.Drawing.Point(116, 102);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(60, 20);
            this.lblFrase.TabIndex = 4;
            this.lblFrase.Text = "Frase:";
            // 
            // txtNm
            // 
            this.txtNm.Enabled = false;
            this.txtNm.Location = new System.Drawing.Point(119, 318);
            this.txtNm.Name = "txtNm";
            this.txtNm.Size = new System.Drawing.Size(126, 20);
            this.txtNm.TabIndex = 5;
            // 
            // txtLetras
            // 
            this.txtLetras.Enabled = false;
            this.txtLetras.Location = new System.Drawing.Point(480, 318);
            this.txtLetras.Name = "txtLetras";
            this.txtLetras.Size = new System.Drawing.Size(126, 20);
            this.txtLetras.TabIndex = 6;
            // 
            // txtBranco
            // 
            this.txtBranco.Enabled = false;
            this.txtBranco.Location = new System.Drawing.Point(305, 318);
            this.txtBranco.Name = "txtBranco";
            this.txtBranco.Size = new System.Drawing.Size(126, 20);
            this.txtBranco.TabIndex = 7;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtBranco);
            this.Controls.Add(this.txtLetras);
            this.Controls.Add(this.txtNm);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.btnLetras);
            this.Controls.Add(this.btnNum);
            this.Controls.Add(this.rctxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.Load += new System.EventHandler(this.FrmExercicio4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rctxtFrase;
        private System.Windows.Forms.Button btnNum;
        private System.Windows.Forms.Button btnLetras;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.TextBox txtNm;
        private System.Windows.Forms.TextBox txtLetras;
        private System.Windows.Forms.TextBox txtBranco;
    }
}