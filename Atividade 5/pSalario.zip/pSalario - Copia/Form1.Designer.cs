﻿namespace pSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblAliINSS = new System.Windows.Forms.Label();
            this.lblAliIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lbSalLiquido = new System.Windows.Forms.Label();
            this.lblDesINSS = new System.Windows.Forms.Label();
            this.lblDesIRPF = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.nupdFilhos = new System.Windows.Forms.NumericUpDown();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtAliINSS = new System.Windows.Forms.TextBox();
            this.txtAliIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtDesIRPF = new System.Windows.Forms.TextBox();
            this.txtDesINSS = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilhos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(47, 42);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(112, 16);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(47, 98);
            this.lblSalBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(84, 16);
            this.lblSalBruto.TabIndex = 1;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(47, 154);
            this.lblNumFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(108, 16);
            this.lblNumFilhos.TabIndex = 2;
            this.lblNumFilhos.Text = "Número de filhos";
            // 
            // lblAliINSS
            // 
            this.lblAliINSS.AutoSize = true;
            this.lblAliINSS.Location = new System.Drawing.Point(48, 288);
            this.lblAliINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliINSS.Name = "lblAliINSS";
            this.lblAliINSS.Size = new System.Drawing.Size(90, 16);
            this.lblAliINSS.TabIndex = 3;
            this.lblAliINSS.Text = "Aliquota INSS";
            // 
            // lblAliIRPF
            // 
            this.lblAliIRPF.AutoSize = true;
            this.lblAliIRPF.Location = new System.Drawing.Point(48, 359);
            this.lblAliIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliIRPF.Name = "lblAliIRPF";
            this.lblAliIRPF.Size = new System.Drawing.Size(89, 16);
            this.lblAliIRPF.TabIndex = 4;
            this.lblAliIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(47, 416);
            this.lblSalFamilia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(97, 16);
            this.lblSalFamilia.TabIndex = 5;
            this.lblSalFamilia.Text = "Salário Família";
            // 
            // lbSalLiquido
            // 
            this.lbSalLiquido.AutoSize = true;
            this.lbSalLiquido.Location = new System.Drawing.Point(48, 476);
            this.lbSalLiquido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbSalLiquido.Name = "lbSalLiquido";
            this.lbSalLiquido.Size = new System.Drawing.Size(97, 16);
            this.lbSalLiquido.TabIndex = 6;
            this.lbSalLiquido.Text = "Salário Líquido";
            // 
            // lblDesINSS
            // 
            this.lblDesINSS.AutoSize = true;
            this.lblDesINSS.Location = new System.Drawing.Point(493, 288);
            this.lblDesINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDesINSS.Name = "lblDesINSS";
            this.lblDesINSS.Size = new System.Drawing.Size(99, 16);
            this.lblDesINSS.TabIndex = 7;
            this.lblDesINSS.Text = "Desconto INSS";
            // 
            // lblDesIRPF
            // 
            this.lblDesIRPF.AutoSize = true;
            this.lblDesIRPF.Location = new System.Drawing.Point(495, 359);
            this.lblDesIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDesIRPF.Name = "lblDesIRPF";
            this.lblDesIRPF.Size = new System.Drawing.Size(98, 16);
            this.lblDesIRPF.TabIndex = 8;
            this.lblDesIRPF.Text = "Desconto IRPF";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(233, 33);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(469, 22);
            this.txtNome.TabIndex = 9;
            this.txtNome.Validated += new System.EventHandler(this.TxtNome_Validated);
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Location = new System.Drawing.Point(233, 95);
            this.mskbxSalBruto.Margin = new System.Windows.Forms.Padding(4);
            this.mskbxSalBruto.Mask = "99000.00";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(201, 22);
            this.mskbxSalBruto.TabIndex = 10;
            this.mskbxSalBruto.Validating += new System.ComponentModel.CancelEventHandler(this.MskbxSalBruto_Validating);
            // 
            // nupdFilhos
            // 
            this.nupdFilhos.Location = new System.Drawing.Point(233, 145);
            this.nupdFilhos.Margin = new System.Windows.Forms.Padding(4);
            this.nupdFilhos.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nupdFilhos.Name = "nupdFilhos";
            this.nupdFilhos.Size = new System.Drawing.Size(160, 22);
            this.nupdFilhos.TabIndex = 11;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(381, 212);
            this.btnVerificar.Margin = new System.Windows.Forms.Padding(4);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(164, 28);
            this.btnVerificar.TabIndex = 12;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.BtnVerificar_Click);
            // 
            // txtAliINSS
            // 
            this.txtAliINSS.Enabled = false;
            this.txtAliINSS.Location = new System.Drawing.Point(176, 279);
            this.txtAliINSS.Margin = new System.Windows.Forms.Padding(4);
            this.txtAliINSS.Name = "txtAliINSS";
            this.txtAliINSS.Size = new System.Drawing.Size(216, 22);
            this.txtAliINSS.TabIndex = 13;
            // 
            // txtAliIRPF
            // 
            this.txtAliIRPF.Enabled = false;
            this.txtAliIRPF.Location = new System.Drawing.Point(176, 351);
            this.txtAliIRPF.Margin = new System.Windows.Forms.Padding(4);
            this.txtAliIRPF.Name = "txtAliIRPF";
            this.txtAliIRPF.Size = new System.Drawing.Size(216, 22);
            this.txtAliIRPF.TabIndex = 14;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(176, 407);
            this.txtSalFamilia.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(216, 22);
            this.txtSalFamilia.TabIndex = 15;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Location = new System.Drawing.Point(176, 468);
            this.txtSalLiquido.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(216, 22);
            this.txtSalLiquido.TabIndex = 16;
            // 
            // txtDesIRPF
            // 
            this.txtDesIRPF.Enabled = false;
            this.txtDesIRPF.Location = new System.Drawing.Point(649, 351);
            this.txtDesIRPF.Margin = new System.Windows.Forms.Padding(4);
            this.txtDesIRPF.Name = "txtDesIRPF";
            this.txtDesIRPF.Size = new System.Drawing.Size(216, 22);
            this.txtDesIRPF.TabIndex = 17;
            // 
            // txtDesINSS
            // 
            this.txtDesINSS.Enabled = false;
            this.txtDesINSS.Location = new System.Drawing.Point(649, 279);
            this.txtDesINSS.Margin = new System.Windows.Forms.Padding(4);
            this.txtDesINSS.Name = "txtDesINSS";
            this.txtDesINSS.Size = new System.Drawing.Size(216, 22);
            this.txtDesINSS.TabIndex = 18;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(124, 215);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(92, 25);
            this.btnLimpar.TabIndex = 19;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(718, 212);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(99, 28);
            this.btnFechar.TabIndex = 20;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtDesINSS);
            this.Controls.Add(this.txtDesIRPF);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliIRPF);
            this.Controls.Add(this.txtAliINSS);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.nupdFilhos);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblDesIRPF);
            this.Controls.Add(this.lblDesINSS);
            this.Controls.Add(this.lbSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliIRPF);
            this.Controls.Add(this.lblAliINSS);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilhos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblAliINSS;
        private System.Windows.Forms.Label lblAliIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lbSalLiquido;
        private System.Windows.Forms.Label lblDesINSS;
        private System.Windows.Forms.Label lblDesIRPF;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
        private System.Windows.Forms.NumericUpDown nupdFilhos;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtAliINSS;
        private System.Windows.Forms.TextBox txtAliIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtDesIRPF;
        private System.Windows.Forms.TextBox txtDesINSS;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Button btnLimpar;
    }
}

