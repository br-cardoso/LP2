﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pSalario
{
    public partial class Form1 : Form
    {
        double salario, salINSS, salIRPF, salFamilia, desINSS, desIRPF, salLiquido, filhos;

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAliINSS.Text= string.Empty;
            txtAliIRPF.Text= string.Empty;
            txtDesINSS.Text= string.Empty;
            txtDesIRPF.Text= string.Empty;
            txtNome.Text= string.Empty;
            txtSalFamilia.Text= string.Empty;
            txtSalLiquido.Text= string.Empty;
            mskbxSalBruto.Text= string.Empty;  
            salario = 0;
            salINSS = 0;
            salIRPF = 0;
            salFamilia = 0;
            desINSS = 0;
            desIRPF = 0;
            filhos = 0;
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            if(salario < 800.48)
            {
                txtAliINSS.Text = "7.65%";
                desINSS = salario * 0.0765;
                txtDesINSS.Text = desINSS.ToString();
            }
            else
                if(salario < 1050.01)
                {
                    txtAliINSS.Text = "8.65%";
                    desINSS = salario * 0.0865;
                    txtDesINSS.Text = desINSS.ToString();
                }
                else
                    if(salario < 1400.78)
                    {
                        txtAliINSS.Text = "9.00%";
                        desINSS = salario * 0.09;
                        txtDesINSS.Text = desINSS.ToString();
                    }
                    else
                        if(salario < 2801.57)
                        {
                            txtAliINSS.Text = "11.0%";
                            desINSS = salario * 0.11;
                            txtDesINSS.Text = desINSS.ToString();
                        }
                        else
                        {
                            txtAliINSS.Text = "Teto";
                            desINSS = 308.17;
                            txtDesINSS.Text = desINSS.ToString();
                        }   

            if(salario < 1257.13)
            {
                txtDesIRPF.Text = "Isento";
                txtAliIRPF.Text = "Isento";
                desIRPF = 0;
            }
            else
                if(salario < 2512.08)
                {
                    txtAliIRPF.Text = "15%";
                    desIRPF = salario * 0.15;
                    txtDesIRPF.Text = desIRPF.ToString();
                }
                else
                {
                    txtAliIRPF.Text = "27.5%";
                    desIRPF = salario * 0.275;
                    txtDesIRPF.Text = desIRPF.ToString();
                }

            if(salario < 435.53)
            {
                filhos = Convert.ToDouble(nupdFilhos.Value);
                salFamilia = filhos * 22.33;
                txtSalFamilia.Text = salFamilia.ToString();
            }
            else
                if(salario < 654.62)
                {
                    filhos = Convert.ToDouble(nupdFilhos.Value);
                    salFamilia = filhos * 15.74;
                    txtSalFamilia.Text = salFamilia.ToString();
                }
                else
                {
                    salFamilia = 0;
                    txtSalFamilia.Text = salFamilia.ToString();
                }

            salLiquido = salario - desINSS - desIRPF + salFamilia;
            txtSalLiquido.Text = salLiquido.ToString();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void TxtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Nome Inválido");
                errorProvider1.SetError(txtNome, "Nome inválido");
                txtNome.Focus();
            }
        }

        private void MskbxSalBruto_Validating(object sender, CancelEventArgs e)
        {
            if(!double.TryParse(mskbxSalBruto.Text, out salario) || (salario <= 0))
            {
                MessageBox.Show("Salário inválido");
                errorProvider2.SetError(mskbxSalBruto, "Salário Inválido");
                mskbxSalBruto.Focus();
            }
        }
    }
}
