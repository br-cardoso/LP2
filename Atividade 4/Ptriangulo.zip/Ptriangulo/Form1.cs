namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxLado1.Text = string.Empty;
            mskbxLado2.Text = string.Empty;
            mskbxLado3.Text = string.Empty;
            mskbxTipo.Text = string.Empty;
            mskbxLado1.Focus();
        }

        private void mskbxLado1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxLado1.Text, out lado1) || (lado1 <= 0))
            {
                MessageBox.Show("N�mero inv�lido");
                mskbxLado1.Focus();
            }
        }

        private void mskbxLado2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxLado2.Text, out lado2) || (lado2 <= 0))
            {
                MessageBox.Show("N�mero inv�lido");
                mskbxLado2.Focus();
            }
        }

        private void mskbxLado3_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxLado3.Text, out lado3) || (lado3 <= 0))
            {
                MessageBox.Show("N�mero inv�lido");
                mskbxLado3.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(lado2 - lado3) < lado1 && (lado2 + lado3) > lado1) &&
            (Math.Abs(lado1 - lado3) < lado2 && (lado1 + lado3) > lado2) &&
            (Math.Abs(lado1 - lado2) < lado3 && lado3 < (lado1 + lado3)))
            {
                if (((lado3 == lado1 || lado1 == lado2) || lado3 == lado2 ) && (lado1 != lado3 || lado2 != lado3))
                {
                    mskbxTipo.Text = ("Tri�ngulo Is�sceles");
                }
                else
                    if (lado1 != lado2 && lado2 != lado3 && lado1 != lado3 )
                {
                    mskbxTipo.Text = ("Tri�ngulo Escaleno");
                }
                else
                      if (lado1 == lado2 && lado2 == lado3)
                {
                    mskbxTipo.Text = ("Tri�ngulo Equil�tero");
                }

                {

                }
            }
        }
    }
}
