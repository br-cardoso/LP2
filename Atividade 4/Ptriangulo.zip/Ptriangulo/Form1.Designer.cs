﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblLado1 = new Label();
            lblLado2 = new Label();
            lblLado3 = new Label();
            mskbxLado1 = new MaskedTextBox();
            mskbxLado2 = new MaskedTextBox();
            mskbxLado3 = new MaskedTextBox();
            mskbxTipo = new MaskedTextBox();
            lblTipo = new Label();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblLado1
            // 
            lblLado1.AutoSize = true;
            lblLado1.Location = new Point(12, 57);
            lblLado1.Name = "lblLado1";
            lblLado1.Size = new Size(54, 20);
            lblLado1.TabIndex = 0;
            lblLado1.Text = "Lado 1";
            // 
            // lblLado2
            // 
            lblLado2.AutoSize = true;
            lblLado2.Location = new Point(12, 121);
            lblLado2.Name = "lblLado2";
            lblLado2.Size = new Size(54, 20);
            lblLado2.TabIndex = 1;
            lblLado2.Text = "Lado 2";
            // 
            // lblLado3
            // 
            lblLado3.AutoSize = true;
            lblLado3.Location = new Point(12, 187);
            lblLado3.Name = "lblLado3";
            lblLado3.Size = new Size(54, 20);
            lblLado3.TabIndex = 2;
            lblLado3.Text = "Lado 3";
            // 
            // mskbxLado1
            // 
            mskbxLado1.Location = new Point(237, 50);
            mskbxLado1.Name = "mskbxLado1";
            mskbxLado1.Size = new Size(125, 27);
            mskbxLado1.TabIndex = 3;
            mskbxLado1.Validated += mskbxLado1_Validated;
            // 
            // mskbxLado2
            // 
            mskbxLado2.Location = new Point(237, 114);
            mskbxLado2.Name = "mskbxLado2";
            mskbxLado2.Size = new Size(125, 27);
            mskbxLado2.TabIndex = 4;
            mskbxLado2.Validated += mskbxLado2_Validated;
            // 
            // mskbxLado3
            // 
            mskbxLado3.Location = new Point(237, 180);
            mskbxLado3.Name = "mskbxLado3";
            mskbxLado3.Size = new Size(125, 27);
            mskbxLado3.TabIndex = 5;
            mskbxLado3.Validated += mskbxLado3_Validated;
            // 
            // mskbxTipo
            // 
            mskbxTipo.Enabled = false;
            mskbxTipo.Location = new Point(179, 257);
            mskbxTipo.Name = "mskbxTipo";
            mskbxTipo.Size = new Size(183, 27);
            mskbxTipo.TabIndex = 6;
            // 
            // lblTipo
            // 
            lblTipo.AutoSize = true;
            lblTipo.Location = new Point(11, 264);
            lblTipo.Name = "lblTipo";
            lblTipo.Size = new Size(126, 20);
            lblTipo.TabIndex = 7;
            lblTipo.Text = "Tipo de Triângulo";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(11, 321);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(94, 29);
            btnCalcular.TabIndex = 8;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(138, 321);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(94, 29);
            btnLimpar.TabIndex = 9;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(268, 321);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(94, 29);
            btnSair.TabIndex = 10;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(lblTipo);
            Controls.Add(mskbxTipo);
            Controls.Add(mskbxLado3);
            Controls.Add(mskbxLado2);
            Controls.Add(mskbxLado1);
            Controls.Add(lblLado3);
            Controls.Add(lblLado2);
            Controls.Add(lblLado1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLado1;
        private Label lblLado2;
        private Label lblLado3;
        private MaskedTextBox mskbxLado1;
        private MaskedTextBox mskbxLado2;
        private MaskedTextBox mskbxLado3;
        private MaskedTextBox mskbxTipo;
        private Label lblTipo;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
    }
}