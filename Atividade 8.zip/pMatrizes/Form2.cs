﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Microsoft.VisualBasic;

namespace pMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void BtnExe_Click(object sender, EventArgs e)
        {
            int[] qtd = new int[3];
            for (int i = 0; i < 3; i++)
            {
                string nome = Interaction.InputBox("Digite o nome do aluno", "Entrada de dados");
                qtd[i] = nome.Length;
                
                foreach (char j in nome) 
                {
                    if (char.IsWhiteSpace(j))
                        qtd[i]--;
                }
                
                listBox1.Items.Add("o nome: " + nome + " tem " + qtd[i] + " caracteres");
            }
            
        }
    }
}
