﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace pMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnEX1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";
            string saida = "";
            for (var i=0; i<20; i++)
            {
                aux = Interaction.InputBox("Digite um número","Entrada de dados");
                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Digite apenas números");
                    i--;

                }
                else
                {
                    saida = vetor [i] + "\n" + saida; 
                }
            }
            /* aux = "";
             for (int i = 19; i >= 0; i--)
                 aux += vetor[i] + " ";

             MessageBox.Show(aux); 

            Array.Reverse(vetor);

            aux = "";

            foreach (var c in vetor)
                aux += c + "\n"; */

            MessageBox.Show(saida);
        }

        private void BtnEX2_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[20, 3];
            double [] vetorAux = new double[20];
            int aluno = 0;
            string aux = "";
            string saida = "";
            for (var i = 0; i < 20; i++)
            {
                for (var j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Digite a nota {j+1} do aluno {i+1}", "Entrada de dados");
                    if (!double.TryParse(aux, out vetor[i, j]) || vetor[i, j] < 0 || vetor[i, j] > 10)
                    {
                        MessageBox.Show("Digite apenas números válidos (de 0 até 10)");
                        i--;
                    }
                    else
                        vetorAux[i] += vetor[i, j]; 
                }
                aluno = i + 1;
                vetorAux[i] = vetorAux[i] / 3.0;
                saida += "Aluno " + aluno + " Média: " + vetorAux[i] + "\n";
            }
            MessageBox.Show(saida);

        }

        private void BtnEX3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void BtnEX4_Click(object sender, EventArgs e)
        {
            ArrayList Alunos = new ArrayList { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            Alunos.Remove("Otavio");
            string ESX = "";
            for (var i = 0; i < 10; i++)
            {
                ESX += Alunos[i] + "\n" ;
            }
            MessageBox.Show(ESX);

        }

        private void BtnEX5_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<Form2>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["Form2"].BringToFront();
            }
            else
            {
                Form2 Frm2 = new Form2();
                Frm2.WindowState = FormWindowState.Maximized;
                Frm2.Show();
            }

        }
    }
}
