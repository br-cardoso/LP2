﻿namespace pMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEX1 = new System.Windows.Forms.Button();
            this.btnEX3 = new System.Windows.Forms.Button();
            this.btnEX2 = new System.Windows.Forms.Button();
            this.btnEX4 = new System.Windows.Forms.Button();
            this.btnEX5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEX1
            // 
            this.btnEX1.Location = new System.Drawing.Point(1, 178);
            this.btnEX1.Name = "btnEX1";
            this.btnEX1.Size = new System.Drawing.Size(139, 94);
            this.btnEX1.TabIndex = 1;
            this.btnEX1.Text = "Exercício 1";
            this.btnEX1.UseVisualStyleBackColor = true;
            this.btnEX1.Click += new System.EventHandler(this.BtnEX1_Click);
            // 
            // btnEX3
            // 
            this.btnEX3.Location = new System.Drawing.Point(327, 178);
            this.btnEX3.Name = "btnEX3";
            this.btnEX3.Size = new System.Drawing.Size(139, 94);
            this.btnEX3.TabIndex = 2;
            this.btnEX3.Text = "Exercício 3";
            this.btnEX3.UseVisualStyleBackColor = true;
            this.btnEX3.Click += new System.EventHandler(this.BtnEX3_Click);
            // 
            // btnEX2
            // 
            this.btnEX2.Location = new System.Drawing.Point(160, 178);
            this.btnEX2.Name = "btnEX2";
            this.btnEX2.Size = new System.Drawing.Size(139, 94);
            this.btnEX2.TabIndex = 3;
            this.btnEX2.Text = "Exercício 2";
            this.btnEX2.UseVisualStyleBackColor = true;
            this.btnEX2.Click += new System.EventHandler(this.BtnEX2_Click);
            // 
            // btnEX4
            // 
            this.btnEX4.Location = new System.Drawing.Point(491, 178);
            this.btnEX4.Name = "btnEX4";
            this.btnEX4.Size = new System.Drawing.Size(139, 94);
            this.btnEX4.TabIndex = 4;
            this.btnEX4.Text = "Exercício 4";
            this.btnEX4.UseVisualStyleBackColor = true;
            this.btnEX4.Click += new System.EventHandler(this.BtnEX4_Click);
            // 
            // btnEX5
            // 
            this.btnEX5.Location = new System.Drawing.Point(649, 178);
            this.btnEX5.Name = "btnEX5";
            this.btnEX5.Size = new System.Drawing.Size(139, 94);
            this.btnEX5.TabIndex = 5;
            this.btnEX5.Text = "Exercício 5";
            this.btnEX5.UseVisualStyleBackColor = true;
            this.btnEX5.Click += new System.EventHandler(this.BtnEX5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnEX5);
            this.Controls.Add(this.btnEX4);
            this.Controls.Add(this.btnEX2);
            this.Controls.Add(this.btnEX3);
            this.Controls.Add(this.btnEX1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEX1;
        private System.Windows.Forms.Button btnEX3;
        private System.Windows.Forms.Button btnEX2;
        private System.Windows.Forms.Button btnEX4;
        private System.Windows.Forms.Button btnEX5;
    }
}

