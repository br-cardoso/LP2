﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double num1, num2, result;

        private void BtnSair_Click(object sender, EventArgs e)
        {
            DialogResult escolha;
            if(MessageBox.Show("Desja sair?","Saída",MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes)
            {
               Close();
            }
            

        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("número inválido");
                txtNum2.Focus();
            }
        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            result = num1 + num2;
            txtResult.Text = result.ToString();
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            result = num1 - num2;
            txtResult.Text = result.ToString();
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            result = num1 * num2;
            txtResult.Text = result.ToString();
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (num2 != 0)
            {
                result = num1 / num2;
                txtResult.Text = result.ToString();
            }
            else
            {
                MessageBox.Show("Não é possível dividir por 0", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();

            }
               
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = String.Empty;
            txtNum2.Text = String.Empty;
            txtResult.Text = String.Empty;

            result = '\0';

            txtNum1.Focus();
        }

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out num1))
            {
                MessageBox.Show("número inválido");
                txtNum1.Focus();
            }
        }
    }
}
